import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'
import Homepage from './Components/Homepage/Homepage'
import { Route, Routes } from 'react-router'

function App() {

  return (
    <>
    <Routes>
      <Route path='/' element={<Homepage/>}/>
    </Routes>
      <Homepage/>
    </>
  )
}

export default App
